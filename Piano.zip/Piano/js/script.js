let whiteKeyArray = ['65', '83', '68', '70', '71', '72', '74', '75', '76', '186', '222', '13', '90', '88']
let blackKeyArray = ['81', '87', '69', '82', '84', '89', '85', '73', '79', '80']
let _whiteKey = document.querySelectorAll('.whiteKey')
// console.log(_whiteKey)
let _blackKey = document.querySelectorAll('.blackKey')

let _audioWhite = document.querySelectorAll('main>section>audio')
// console.log(_audio)
let _audioBlack = document.querySelectorAll('main>.audio-black-key>audio')
// keydown white keys ********
window.addEventListener('keydown', (event) => {
    if (event.repeat) return
    for (i = 0; i < whiteKeyArray.length; i++) {
        // console.log(whiteKeyArray[i])
        _whiteKey[i]
        if (event.keyCode == whiteKeyArray[i]) {
            _audioWhite[i].currentTime = 0
            _audioWhite[i].play()
            // alert('working')
            _whiteKey[i].classList.add('whiteKeyPress')
        }
    }
    // keydown black keys ********
    for (k = 0; k < blackKeyArray.length; k++) {
        // console.log(blackKeyArray[k])
        _blackKey[i]
        if (event.keyCode == blackKeyArray[k]) {
            _audioBlack[k].currentTime = 0
            _audioBlack[k].play()
            _blackKey[k].classList.add('blackKeyPress')
        }
    }
})
// end

// keyup white keys ********
window.addEventListener('keyup', (event) => {
    for (i = 0; i < whiteKeyArray.length; i++) {
        // console.log(whiteKeyArray[i])
        _whiteKey[i]
        if (event.keyCode == whiteKeyArray[i]) {
            // alert('working')
            _whiteKey[i].classList.remove('whiteKeyPress')
        }
    }
    // keyup black keys ********
    for (k = 0; k < blackKeyArray.length; k++) {
        // console.log(blackKeyArray[k])
        _blackKey[i]
        if (event.keyCode == blackKeyArray[k]) {
            _blackKey[k].classList.remove('blackKeyPress')
        }
    }
})
// end